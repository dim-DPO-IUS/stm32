#ifndef MYLIB_H
#define MYLIB_H

#include "stm32f4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

// ============================================================================
//  ТЕСТОВАЯ ФУНКЦИЯ ЗАПИСИ ВО FLASH (СЕКТОР 4)
// ============================================================================

/**
 * @brief Тестовая запись константных данных в сектор 4
 * @return HAL_OK если запись успешна, иначе код ошибки HAL
 */
static inline HAL_StatusTypeDef Test_Flash_Write(void)
{
    // Тестовые данные (16 байт) для записи по адресу 0x08010000
    const uint8_t test_data[16] = {
        0xAA, 0xBB, 0xCC, 0xDD,
        0x11, 0x22, 0x33, 0x44,
        0x55, 0x66, 0x77, 0x88,
        0x99, 0x00, 0xFF, 0xEE
    };

    uint32_t target_addr = 0x08010000;
    HAL_StatusTypeDef status = HAL_OK;

    // 1. Разблокировка Flash
    if (HAL_FLASH_Unlock() != HAL_OK)
    {
        return HAL_ERROR;
    }

    // 2. Очистка флагов ошибок
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR |
                           FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR | FLASH_FLAG_PGSERR);

    // 3. Запись данных по словам (32 бита)
    for (uint32_t i = 0; i < sizeof(test_data); i += 4)
    {
        // Формируем 32-битное слово из 4 байт
        uint32_t word = 0;
        for (uint32_t j = 0; j < 4 && (i + j) < sizeof(test_data); j++)
        {
            word |= ((uint32_t)test_data[i + j] << (j * 8));
        }

        // Программируем слово
        status = HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, target_addr + i, word);
        if (status != HAL_OK)
        {
            break;
        }
    }

    // 4. Блокировка Flash
    HAL_FLASH_Lock();

    return status;
}

#endif /* MYLIB_H */
