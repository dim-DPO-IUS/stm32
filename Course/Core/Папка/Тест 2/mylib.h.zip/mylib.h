#ifndef MYLIB_H
#define MYLIB_H

#include "stm32f4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

static inline HAL_StatusTypeDef Test_Flash_Write(void)
{
    // ПАТТЕРН B: визуально узнаваемая последовательность
    const uint8_t test_data[16] = {
        0x11, 0x22, 0x33, 0x44,
        0x55, 0x66, 0x77, 0x88,
        0x99, 0xAA, 0xBB, 0xCC,
        0xDD, 0xEE, 0xFF, 0x00
    };

    uint32_t target_addr = 0x08010000;
    HAL_StatusTypeDef status = HAL_OK;

    // 1. Разблокировка Flash
    if (HAL_FLASH_Unlock() != HAL_OK)
        return HAL_ERROR;

    // 2. Очистка флагов ошибок
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR |
                           FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR | FLASH_FLAG_PGSERR);

    // 3. СТИРАНИЕ СЕКТОРА 4
    FLASH_EraseInitTypeDef erase = {
        .TypeErase = FLASH_TYPEERASE_SECTORS,
        .VoltageRange = FLASH_VOLTAGE_RANGE_3,
        .Sector = FLASH_SECTOR_4,
        .NbSectors = 1
    };
    uint32_t sector_error = 0;
    status = HAL_FLASHEx_Erase(&erase, &sector_error);
    if (status != HAL_OK)
    {
        HAL_FLASH_Lock();
        return status;
    }

    // 4. ЗАПИСЬ ДАННЫХ
    for (uint32_t i = 0; i < sizeof(test_data); i += 4)
    {
        uint32_t word = 0;
        for (uint32_t j = 0; j < 4 && (i + j) < sizeof(test_data); j++)
            word |= ((uint32_t)test_data[i + j] << (j * 8));

        status = HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, target_addr + i, word);
        if (status != HAL_OK) break;
    }

    HAL_FLASH_Lock();
    return status;
}

#endif /* MYLIB_H */
