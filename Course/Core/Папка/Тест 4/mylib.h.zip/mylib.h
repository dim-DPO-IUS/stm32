#ifndef MYLIB_H
#define MYLIB_H

#include "stm32f4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

// ============================================================================
//  КОНФИГУРАЦИЯ
// ============================================================================
#define SECTOR_4_START          0x08010000UL
#define SECTOR_4_END            0x0801FFFFUL
#define MAX_DATA_LEN            64

// ============================================================================
//  ТЕСТОВЫЙ HEX-ФАЙЛ (АДРЕСА 0x0000, 0x0010... + _ext_linear_addr = 0x08010000)
// ============================================================================
static const char* test_hex_lines[] = {
    ":100000000102030405060708090A0B0C0D0E0F1060",
    ":1000100000010002000300040005000600070008B4",
    ":10002000112233445566778899AABBCCDDEEFF00D8",
    ":10003000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC8",
    ":1000400000000000000000000000000000000000A8",
    ":10005000123456789ABCDEF0123456789ABCDEF0DC",
    ":00000001FF"
};
#define HEX_LINES_COUNT (sizeof(test_hex_lines) / sizeof(test_hex_lines[0]))

// ============================================================================
//  ХРАНИЛИЩЕ ДАННЫХ ДЛЯ ЗАПИСИ
// ============================================================================
#define MAX_BLOCKS 16
static uint32_t _block_addr[MAX_BLOCKS];
static uint8_t  _block_data[MAX_BLOCKS][MAX_DATA_LEN];
static uint8_t  _block_len[MAX_BLOCKS];
static uint32_t _block_count = 0;

static uint32_t _ext_linear_addr = 0x08010000;  // Базовый адрес сектора 4
static bool _processing_done = false;

// ============================================================================
//  ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================================
static inline uint8_t _hexCharToByte(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return 0;
}

static bool _parseHexLine(const char* line)
{
    if (line[0] != ':') return true;

    uint16_t len = strlen(line);
    if (len < 11) return false;

    uint8_t bytes[128];
    uint8_t byte_count = 0;

    // len - 2, т.к. CRC занимает 2 символа
    for (uint16_t i = 1; i < len - 2; i += 2)
    {
        bytes[byte_count++] = (_hexCharToByte(line[i]) << 4) | _hexCharToByte(line[i+1]);
    }

    uint8_t rec_len  = bytes[0];
    uint16_t addr    = (bytes[1] << 8) | bytes[2];
    uint8_t rtype    = bytes[3];

    uint32_t abs_addr = _ext_linear_addr + addr;

    if (rtype == 0x04 && rec_len == 2)
    {
        _ext_linear_addr = ((uint32_t)bytes[4] << 24) | ((uint32_t)bytes[5] << 16);
        return true;
    }

    if (rtype == 0x01)
    {
        _processing_done = true;
        return true;
    }

    if (rtype == 0x00 && rec_len > 0)
    {
        if (abs_addr < SECTOR_4_START || abs_addr > SECTOR_4_END)
            return false;

        if (_block_count < MAX_BLOCKS)
        {
            _block_addr[_block_count] = abs_addr;
            _block_len[_block_count] = rec_len;
            for (uint8_t i = 0; i < rec_len; i++)
                _block_data[_block_count][i] = bytes[4 + i];
            _block_count++;
        }
    }

    return true;
}

// ============================================================================
//  ОСНОВНАЯ ТЕСТОВАЯ ФУНКЦИЯ
// ============================================================================
static inline HAL_StatusTypeDef Test_Flash_Write(void)
{
    HAL_StatusTypeDef status = HAL_OK;

    // 1. Сброс состояния
    _ext_linear_addr = 0x08010000;  // Базовый адрес сектора 4
    _processing_done = false;
    _block_count = 0;

    // 2. Парсинг всех строк
    for (uint32_t i = 0; i < HEX_LINES_COUNT; i++)
    {
        if (!_parseHexLine(test_hex_lines[i]))
        {
            return HAL_ERROR;
        }
    }

    if (!_processing_done)
        return HAL_ERROR;

    // 3. Разблокировка Flash
    if (HAL_FLASH_Unlock() != HAL_OK)
        return HAL_ERROR;

    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR |
                           FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR | FLASH_FLAG_PGSERR);

    // 4. Стирание сектора 4
    FLASH_EraseInitTypeDef erase = {
        .TypeErase = FLASH_TYPEERASE_SECTORS,
        .VoltageRange = FLASH_VOLTAGE_RANGE_3,
        .Sector = FLASH_SECTOR_4,
        .NbSectors = 1
    };
    uint32_t sector_error = 0;
    status = HAL_FLASHEx_Erase(&erase, &sector_error);
    if (status != HAL_OK)
    {
        HAL_FLASH_Lock();
        return status;
    }

    // 5. Запись всех блоков
    for (uint32_t b = 0; b < _block_count; b++)
    {
        uint32_t addr = _block_addr[b];
        uint8_t* data = _block_data[b];
        uint8_t len = _block_len[b];

        for (uint32_t i = 0; i < len; i += 4)
        {
            uint32_t word = 0xFFFFFFFF;
            for (uint32_t j = 0; j < 4 && (i + j) < len; j++)
                ((uint8_t*)&word)[j] = data[i + j];

            status = HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr + i, word);
            if (status != HAL_OK) break;
        }
        if (status != HAL_OK) break;
    }

    HAL_FLASH_Lock();
    return status;
}

#endif /* MYLIB_H */
